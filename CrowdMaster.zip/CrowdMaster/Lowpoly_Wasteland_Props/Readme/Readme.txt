This is a part of the Lowpoly Wasteland Outpost.

https://www.assetstore.unity3d.com/en/?stay#!/content/132243

In this package you will find:

- Barrel - 470 tris;
- Radio - 176 tris; 
- Tire - 240 tris;
- 2 boxes - 180 and 212 tris;
- Bricks and road signs - 28-104 tris;
- Tileable sand texture 1024x1024;

This package has static lighting, but all lightmaps are deleted for the less package size. Try to rebake lighting if you want.